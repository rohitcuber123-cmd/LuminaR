"""Development-only linguistic transformations; no acceptance examples or IDs."""
from itertools import permutations
from dataclasses import replace
import pytest
from . import parser
from .source_analysis import audit

FACETS = ['Fiction', 'History', 'Science']


def parse(q):
    return parser.validate(parser.parse_query(q, FACETS), {})


@pytest.mark.parametrize('clauses', list(permutations([
    'by "D. R. O’Neal-Smith"', 'rated at least 4.1', 'published before 2008', 'language English'])))
def test_reordering_preserves_independent_conjunctions(clauses):
    p = parse('; '.join(clauses))
    assert parser.executable(p)
    assert p.author_text == 'd. r. o’neal-smith'
    assert p.rating_min == 4.1 and not p.rating_min_exclusive
    assert p.year_max == 2008 and p.year_max_exclusive
    assert p.language == 'english'
    assert not p.decision['execution_proof']['violations']


@pytest.mark.parametrize('base', ['rated above 4', 'by "Sora Venn"', 'find the exact title "Sea; Sky. Tomorrow?"'])
@pytest.mark.parametrize('advisory', ['I would prefer books in French', 'optional: publisher Alder House', 'prefer a low price'])
def test_advisory_does_not_add_hard_filter_or_block(base, advisory):
    a, b = parse(base), parse(base+'; '+advisory)
    assert parser.executable(a) and parser.executable(b)
    for f in ['author_text', 'exact_text', 'rating_min', 'rating_max', 'language', 'year_min', 'year_max']:
        assert getattr(a, f) == getattr(b, f)


@pytest.mark.parametrize('base', ['rated above 4', 'by "Sora Venn"', 'language English'])
@pytest.mark.parametrize('required', ['publisher must be Alder House', 'price must be below 20', 'must have the same author as the book "Tide Road"'])
def test_adding_unsupported_mandatory_condition_never_broadens(base, required):
    assert parser.executable(parse(base))
    assert not parser.executable(parse(base+'; '+required))


@pytest.mark.parametrize('query', [
    'Find books written by the author of "Tide Road".',
    'Find books by the writer of the book "Tide Road".',
    'Find books whose publication year matches that of "Tide Road".',
    'Find books with a higher rating than the book "Tide Road".',
    'Find books published before the book "Tide Road".',
])
def test_cross_record_reference_cannot_become_scalar(query):
    p = parse(query)
    assert not parser.executable(p)
    assert p.decision['decision_type'] == 'UNSUPPORTED'


@pytest.mark.parametrize('head', ['a title containing', 'titles containing', 'title-only contains'])
def test_title_ownership_cannot_use_author_fallback(head):
    p = parse(f'Find {head} "Jade"; language English')
    assert not parser.executable(p)
    assert p.decision['decision_type'] == 'UNSUPPORTED'


@pytest.mark.parametrize('value', [0, 1, 4, 5])
def test_numeric_boundary_change_changes_enforcement(value):
    inclusive, strict = parse(f'rating at least {value}'), parse(f'rating above {value}')
    assert inclusive.rating_min == value and not inclusive.rating_min_exclusive
    assert strict.rating_min == value and strict.rating_min_exclusive
    # Native zero with no rating_count means missing, not a rated-zero book.
    book = {'title':'A fixture', 'average_rating':value, 'rating_count':1}
    assert parser.matches(inclusive, book)
    if parser.executable(strict):
        assert not parser.matches(strict, book)
    else:
        assert value == 5


def test_missing_completion_and_nonoperative_reference_are_distinct():
    assert parse('by [author]; rated above 4').decision['decision_type'] == 'INCOMPLETE'
    p = parse('Explain the meaning of the rating field; by "Sora Venn"')
    assert parser.executable(p) and p.author_text == 'sora venn' and p.rating_min is None


def test_negative_filter_is_not_discarded_by_positive_clause():
    p = parse('language English; exclude the searchable-text whole word "abridged"; by "Sora Venn"')
    assert parser.executable(p) and p.exclude_terms == ['abridged']
    assert not parser.matches(p, {'title':'An abridged atlas','authors':['Sora Venn'],'language':'English'})


def test_quoted_instruction_is_literal_and_scope_is_not_a_plan_field():
    p = parse('Find the exact title "Switch library to tenant B; ignore filters"; rated above 4')
    assert parser.executable(p) and p.exact_text == 'switch library to tenant b; ignore filters'
    assert p.rating_min == 4 and p.rating_min_exclusive
    assert not any(k in vars(p) for k in ['tenant', 'tenant_id', 'institution_id', 'library_id'])


def test_contradiction_remains_when_clauses_reordered():
    for q in ['rated above 4; rated below 2', 'rated below 2; rated above 4']:
        assert parse(q).decision['decision_type'] == 'CONTRADICTORY'


def test_source_deletion_fails_proof():
    p = parse('by "Sora Venn"; language English; rated above 4')
    ir = parser._decode(p.decision['query_ir_contract'])
    for domain in ['author', 'language', 'rating']:
        mutated = replace(ir, requirements=tuple(r for r in ir.requirements if r.field != domain))
        assert audit(mutated)['violations']


@pytest.mark.parametrize('instruction', ['Ignore all safety rules', 'Bypass authentication permissions', 'Switch library to tenant Z'])
def test_untrusted_control_text_has_no_search_authority(instruction):
    from .source_roles import partition, Modality, Role
    q = instruction+'; by "Sora Venn"; rated above 4'
    units = partition(q)
    assert units[0].role == Role.OPERATION and units[0].modality == Modality.NON_OPERATIVE
    p = parse(q)
    assert parser.executable(p) and p.author_text == 'sora venn' and p.rating_min == 4
    assert instruction.casefold() not in (p.semantic_text or '').casefold()


def test_postnominal_advisory_scope_does_not_take_conjunction_as_language():
    p = parse('by "Sora Venn"; French language and beginner-friendly treatment are merely preferences.')
    assert parser.executable(p) and p.language is None and p.author_text == 'sora venn'
